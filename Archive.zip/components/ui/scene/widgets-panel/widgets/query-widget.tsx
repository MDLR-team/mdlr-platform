import WidgetPaper from "../blocks/widget-paper/widget-paper";

const QueryWidget = () => {
  return (
    <WidgetPaper title={"Queries"}>
      <></>
    </WidgetPaper>
  );
};

export default QueryWidget;
