class WidgetService {
  constructor() {}
}

export default WidgetService;
